package br.ufc.quixada.dadm.entrega1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {

    private TextView texto;
    //private Button botao;
    public ToggleButton interruptor;

    //private TextView texto2;
    //private Button button2;
    ArrayList<String> lista;
    EditText edtInput;

    AutoCompleteTextView autoCompleteTextView;
    String[] strings = {"Um", "Dois", "Três", "Quatro", "Cinco", "Seis",
            "Sete", "Oito", "Nove", "Dez"};
    ArrayAdapter<String> adapter;

    Spinner spinner;
    String[] pais = {"Brasil", "México", "Taiwan", "Ucrânia", "Israel"};

    RadioGroup radioGroup;
    RadioButton radioButton;
    TextView textView4;

    ListView listView;

    GridView gridView;

    static final String[] gridViewValue = new String[]{
            "Fogo","Água","Terra","Ar","Raio","Metal"
    };

    MediaPlayer meuSom;
    //TabItem tab1, tab2, tab3;

    private TabLayout tabLayout;
    private ViewPager viewPager;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        meuSom = MediaPlayer.create(this, R.raw.rapaaaaz);

        tabLayout = findViewById(R.id.tabLayout);
        viewPager = findViewById(R.id.viewpager);

        tabLayout.setupWithViewPager(viewPager);

        ViewPagerAdapter vpAdapter = new ViewPagerAdapter(getSupportFragmentManager(), FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        vpAdapter.addFragment(new FirstFragment(), "Tab 1");
        vpAdapter.addFragment(new SecondFragment(), "Tab 2");
        vpAdapter.addFragment(new ThirdFragment(), "Tab 3");
        viewPager.setAdapter(vpAdapter);

        texto = findViewById(R.id.textView);
        //botao = findViewById(R.id.button);
        interruptor = findViewById(R.id.toggleButton);
        lista = new ArrayList<>();
        edtInput = findViewById(R.id.textoEditavel);

        interruptor.setOnCheckedChangeListener((buttonView, isChecked) -> {
            texto.setText(converteParaTexto(isChecked));
        });

        autoCompleteTextView = findViewById(R.id.autoCompleteTextView);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, strings);

        autoCompleteTextView.setThreshold(1);
        autoCompleteTextView.setAdapter(adapter);

        spinner = findViewById(R.id.spinner);

        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, pais);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter2);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int posicao, long id){
                String valor = parent.getItemAtPosition(posicao).toString();
                Toast.makeText(MainActivity.this, valor, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent){}
        });

        radioGroup = findViewById(R.id.radioGroup);
        textView4 = findViewById(R.id.textView4);

        Button buttonApply = findViewById(R.id.button3);
        buttonApply.setOnClickListener(v -> {
            int radioId = radioGroup.getCheckedRadioButtonId();
            radioButton = findViewById(radioId);
            textView4.setText("Sua escolha: " + radioButton.getText());
        });

        Button button5 = findViewById(R.id.button5);
        button5.setOnLongClickListener(v -> {
            Toast.makeText(getApplicationContext(),
                    "Pode soltar", Toast.LENGTH_SHORT).show();
            return true;
        });
        button5.setOnClickListener(v -> Toast.makeText(getApplicationContext(), "Segure por mais um tempo", Toast.LENGTH_SHORT).show());

        listView = (ListView)findViewById(R.id.listview);
        ArrayList<String> arrayList = new ArrayList<>();

        arrayList.add("ListView com ArrayAdapter");
        arrayList.add("O item 3 sobre");
        arrayList.add("Arrays (Lists)");
        arrayList.add("tem o arraylist aparecendo");
        arrayList.add("no Android Studio");
        arrayList.add("em Run ao lado de Version Control");
        arrayList.add("a cada adição de texto.");

        ArrayAdapter<?> arrayAdapter2 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, arrayList);
        listView.setAdapter(arrayAdapter2);

        gridView = findViewById(R.id.gridViewSimple);

        ArrayAdapter<String> adapter3 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, gridViewValue);
        gridView.setAdapter(adapter3);

        gridView.setOnItemClickListener((parent, view, position, id) -> Toast.makeText(getApplicationContext(), ((TextView) view).getText()+" foi selecionado", Toast.LENGTH_SHORT).show());
    }

    public void playMusica(View view){
        meuSom.start();
    }

    @Override
    protected void onPause(){
        super.onPause();
        meuSom.release();
    }

    @Override
    public boolean onCreateOptionsMenu(@NonNull Menu menu){
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item){
        if(item.getItemId() == R.id.escolha1) {
            Toast.makeText(this, "Item 1 selecionado", Toast.LENGTH_SHORT).show();
            return true;
        }else if(item.getItemId() == R.id.escolha2)  {
            Toast.makeText(this, "Item 2 selecionado", Toast.LENGTH_SHORT).show();
            return true;
        }else if(item.getItemId() == R.id.escolha3)  {
            Toast.makeText(this, "Item 3 selecionado", Toast.LENGTH_SHORT).show();
            return true;
        }else if(item.getItemId() == R.id.escolha4)  {
            Toast.makeText(this, "Item 4 selecionado", Toast.LENGTH_SHORT).show();
            return true;
        }else if(item.getItemId() == R.id.escolha5)  {
            Toast.makeText(this, "Item 5 selecionado", Toast.LENGTH_SHORT).show();
            return true;
        }else if(item.getItemId() == R.id.escolha6)  {
            Toast.makeText(this, "Item 6 selecionado", Toast.LENGTH_SHORT).show();
            return true;
        }else if(item.getItemId() == R.id.escolha7)  {
            Toast.makeText(this, "Item 1 selecionado", Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }

    private String converteParaTexto(boolean isChecked){
        return (isChecked) ? "Ligado" : "Desligado";
    }

    public void onClickButton02(View view ){
        String txt = edtInput.getText().toString();
        lista.add(txt);
        edtInput.setText("");

        for(int i = 0; i < lista.size(); ++i) {
            Log.d("MainActivity", lista.get(i));
        }
    }

    public void checkRadioButton(View v){
        int radioId = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(radioId);
        Toast.makeText(this, "Selected radio button: "+ radioButton.getText(), Toast.LENGTH_SHORT).show();
    }

    public void mostrarPopUp(View view){
        PopupMenu popUp = new PopupMenu(this, view);
        popUp.setOnMenuItemClickListener(this);
        popUp.inflate(R.menu.popup_menu);
        popUp.show();
    }

    @Override
    public boolean onMenuItemClick(MenuItem item){
        if(item.getItemId() == R.id.escolha1) {
            Toast.makeText(this, "Selecionada escolha 1", Toast.LENGTH_SHORT).show();
            return true;
        }else if(item.getItemId() == R.id.escolha2)  {
            Toast.makeText(this, "Selecionada escolha 2", Toast.LENGTH_SHORT).show();
            return true;
        }else if(item.getItemId() == R.id.escolha3)  {
            Toast.makeText(this, "Selecionada escolha 3", Toast.LENGTH_SHORT).show();
            return true;
        }else if(item.getItemId() == R.id.escolha4)  {
            Toast.makeText(this, "Selecionada escolha 4", Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }
}