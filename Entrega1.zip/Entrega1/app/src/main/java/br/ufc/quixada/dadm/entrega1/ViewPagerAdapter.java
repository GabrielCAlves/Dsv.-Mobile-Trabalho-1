package br.ufc.quixada.dadm.entrega1;



import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
//import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import java.util.ArrayList;
import java.util.List;

public class ViewPagerAdapter extends /*FragmentStateAdapter*/FragmentPagerAdapter {
    private List<Fragment> fragmentList = new ArrayList<>();
    private List<String> titleList = new ArrayList<>();

    public ViewPagerAdapter(@NonNull /*FragmentActivity fragmentActivity*/FragmentManager fm, int behavior){
        super(/*fragmentActivity*/ fm, behavior);
    }

    @NonNull
    @Override
    public Fragment getItem(int position){
        return fragmentList.get(position);
    }

    @Override
    public int getCount(){
        return fragmentList.size();
    }

    public void addFragment(Fragment fragment, String title){
        fragmentList.add(fragment);
    }

    /*@NonNull
    @Override
    public Fragment getItem(int position) {
        return ;
    }

    public String getTitle(int position){
        return titleList.get(position);
    }

    public void addFragment(Fragment fragment, String title){
        fragmentList.add(fragment);
        titleList.add(title);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position){
        return fragmentList.get(position);
    }

    @Override
    public int getItemCount(){
        return fragmentList.size();
    }*/


}
